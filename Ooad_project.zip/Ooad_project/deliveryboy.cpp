#ifndef delivery_boy_cpp
#define delivery_boy_cpp
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <cmath>
#include <fstream>  
using namespace std;

using namespace std;

class Deliveryboy
{   public:
    string name;
    unsigned long long int contact_number;
};

#endif